import { game } from '/star-sdk/v1/dom.js';
import createAudio from '/star-sdk/audio.js';
import {
  createBoard, findMatches, removeMatches,
  applyGravity, fillBoard, swapGems, isAdjacent,
  hasValidMove, GEM_TYPES
} from './js/board.js';

// ── Constants ────────────────────────────────────────────────
const COLS = 8, ROWS = 8;
const GEM_SIZE = 40;
const GRID_X = (360 - COLS * GEM_SIZE) / 2; // 20
const GRID_Y = 90;
const MAX_MOVES = 35;
const TARGET_SCORE = 5000;

const GEM_COLORS  = ['#00BFFF','#FFD700','#FF3366','#AA44FF','#00FF88','#FF6600'];
const GEM_GLOW    = ['#00BFFFCC','#FFD700CC','#FF3366CC','#AA44FFCC','#00FF88CC','#FF6600CC'];
const GEM_NAMES   = ['KAMEHAMEHA','SUPER SAIYAN','GALICK GUN','SPIRIT BOMB','SENZU BEAN','DRAGON BALL'];
const COMBO_MSGS  = ['SUGOI!','NANI?!','YATTA!','MASAKA!','KAKUSEI!!','MASTERED!!'];
const POWER_MSGS  = ['KAMEHAMEHA!!!','FINAL FLASH!!','SPIRIT BOMB!!','ULTRA INSTINCT!','OVER 9000!!!'];

// ── Asset Loading ─────────────────────────────────────────────
const BG_URL = 'https://vtelpopqybfytrgzkomj.supabase.co/storage/v1/object/public/game-assets/public/5630908a-fac9-4232-9b3d-c3e5ad9b5c9f/5c6d6e42-a06d-4c46-b1ef-06bbef59db0e/57608909-5684-4beb-97c0-d0f5c1485715.jpg';
const GEM_URLS = [
  'https://vtelpopqybfytrgzkomj.supabase.co/storage/v1/object/public/game-assets/public/5630908a-fac9-4232-9b3d-c3e5ad9b5c9f/5c6d6e42-a06d-4c46-b1ef-06bbef59db0e/9c71bd31-049e-4986-8b40-b3bdfa56e90b.png', // blue - Kamehameha
  'https://vtelpopqybfytrgzkomj.supabase.co/storage/v1/object/public/game-assets/public/5630908a-fac9-4232-9b3d-c3e5ad9b5c9f/5c6d6e42-a06d-4c46-b1ef-06bbef59db0e/433e35b3-f454-4417-8b06-28361d1fb20b.png', // gold - Super Saiyan
  null, // red - Galick Gun (canvas fallback)
  'https://vtelpopqybfytrgzkomj.supabase.co/storage/v1/object/public/game-assets/public/5630908a-fac9-4232-9b3d-c3e5ad9b5c9f/5c6d6e42-a06d-4c46-b1ef-06bbef59db0e/4e195a7e-5c4c-400f-9dc1-fea55ce6045d.png', // purple - Spirit Bomb
  null, // green - Senzu Bean (canvas fallback)
  null, // orange - Dragon Ball (canvas fallback)
];

const bgImg = new Image();
bgImg.src = BG_URL;

const gemImgs = GEM_URLS.map((url, i) => {
  if (!url) return null;
  const img = new Image();
  img.src = url;
  return img;
});

// ── Helper ───────────────────────────────────────────────────
function inRect(pt, x, y, w, h) {
  return pt && pt.x >= x && pt.x <= x + w && pt.y >= y && pt.y <= y + h;
}
function cellAt(px, py) {
  const c = Math.floor((px - GRID_X) / GEM_SIZE);
  const r = Math.floor((py - GRID_Y) / GEM_SIZE);
  if (c < 0 || c >= COLS || r < 0 || r >= ROWS) return null;
  return { r, c };
}
function gemCenter(r, c) {
  return {
    x: GRID_X + c * GEM_SIZE + GEM_SIZE / 2,
    y: GRID_Y + r * GEM_SIZE + GEM_SIZE / 2
  };
}
function lerp(a, b, t) { return a + (b - a) * t; }

// ── Draw Gem ─────────────────────────────────────────────────
function drawGem(ctx, gemType, x, y, size, alpha = 1, glowExtra = 0, pulse = 0) {
  const img = gemImgs[gemType];
  const color = GEM_COLORS[gemType];
  const glowColor = GEM_GLOW[gemType];
  const r = size / 2;
  const cx = x + r;
  const cy = y + r;

  ctx.save();
  ctx.globalAlpha = alpha;

  if (img && img.complete && img.naturalWidth > 0) {
    // Draw glow
    if (glowExtra > 0 || pulse > 0) {
      ctx.shadowBlur = 18 + glowExtra + pulse * 12;
      ctx.shadowColor = color;
    }
    ctx.drawImage(img, x, y, size, size);
    ctx.shadowBlur = 0;
  } else {
    // Canvas fallback: draw a glowing gradient orb
    const grad = ctx.createRadialGradient(cx - r * 0.25, cy - r * 0.25, r * 0.05, cx, cy, r * 0.95);
    grad.addColorStop(0, '#ffffff');
    grad.addColorStop(0.3, color);
    grad.addColorStop(1, glowColor.slice(0, 7) + '33');

    ctx.shadowBlur = 14 + glowExtra + pulse * 10;
    ctx.shadowColor = color;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 0.88, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    // Shine
    const shine = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.35, 0, cx - r * 0.3, cy - r * 0.35, r * 0.5);
    shine.addColorStop(0, 'rgba(255,255,255,0.6)');
    shine.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.beginPath();
    ctx.arc(cx, cy, r * 0.88, 0, Math.PI * 2);
    ctx.fillStyle = shine;
    ctx.fill();

    ctx.shadowBlur = 0;

    // Star symbol for dragon ball type
    if (gemType === 5) {
      ctx.fillStyle = '#FFD700';
      ctx.font = `bold ${Math.floor(size * 0.38)}px serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('★', cx, cy);
    }
  }
  ctx.restore();
}

// ── Particles ────────────────────────────────────────────────
function makeParticle(x, y, color) {
  const angle = Math.random() * Math.PI * 2;
  const spd = 80 + Math.random() * 180;
  return {
    x, y,
    vx: Math.cos(angle) * spd,
    vy: Math.sin(angle) * spd - 60,
    color,
    size: 3 + Math.random() * 5,
    life: 1,
    maxLife: 0.5 + Math.random() * 0.4
  };
}

function makeFloatText(x, y, text, color, size = 22, life = 1.2) {
  return { x, y, text, color, size, life, maxLife: life, vy: -55 };
}

// ── Main Game ─────────────────────────────────────────────────
game((g) => {
  const { ctx, width, height } = g;

  // Audio
  const audio = createAudio();
  audio.preload({
    match:   { synth: 'coin',    volume: 0.5 },
    combo:   { synth: 'powerup', volume: 0.7 },
    big:     { synth: 'unlock',  volume: 0.8 },
    swap:    { synth: 'click',   volume: 0.3 },
    invalid: { synth: 'error',   volume: 0.4 },
    win:     { synth: 'success', volume: 0.9 },
    lose:    { synth: 'error',   volume: 0.7 },
  });

  // State
  let grid = createBoard(COLS, ROWS);
  let phase = 'idle'; // idle | selected | processing | gameover | win | intro
  let selected = null;
  let score = 0;
  let moves = MAX_MOVES;
  let combo = 0;
  let highScore = parseInt(localStorage.getItem('dbcHighScore') || '0');

  // Animation
  let phaseTimer = 0;
  let matchedSet = new Set();
  let swapAnim = null; // { r1,c1,r2,c2, prog, back }
  let particles = [];
  let floatTexts = [];
  let shakeX = 0, shakeY = 0;
  let bgPulse = 0;
  let introTimer = 1.5;
  let screenfx = 0; // flash effect

  // ── Helpers ───────────────────────────────────────────────
  function addExplosion(x, y, gemType, count = 10) {
    const color = GEM_COLORS[gemType];
    for (let i = 0; i < count; i++) particles.push(makeParticle(x, y, color));
  }

  function addFloat(x, y, text, color = '#FFD700', size = 22) {
    floatTexts.push(makeFloatText(x, y, text, color, size));
  }

  function shake(amt) {
    shakeX = amt; shakeY = amt;
  }

  function flash(amt) { screenfx = amt; }

  // ── Input ──────────────────────────────────────────────────
  function handleInput(dt) {
    if (phase === 'intro') {
      introTimer -= dt;
      if (introTimer <= 0 || g.tap) phase = 'idle';
      return;
    }

    if (phase === 'gameover' || phase === 'win') {
      if (g.tap) {
        // Check restart button
        const bx = width / 2 - 100, by = height / 2 + 60;
        if (inRect(g.tap, bx, by, 200, 50)) restartGame();
      }
      return;
    }

    if (phase !== 'idle' && phase !== 'selected') return;

    if (g.tap) {
      const cell = cellAt(g.tap.x, g.tap.y);
      if (!cell) { selected = null; phase = 'idle'; return; }
      const { r, c } = cell;

      if (!selected) {
        selected = { r, c };
        phase = 'selected';
        audio.play('swap');
      } else {
        if (selected.r === r && selected.c === c) {
          selected = null; phase = 'idle';
          return;
        }
        if (isAdjacent(selected.r, selected.c, r, c)) {
          trySwap(selected.r, selected.c, r, c);
          selected = null;
        } else {
          selected = { r, c };
          audio.play('swap');
        }
      }
    }
  }

  function trySwap(r1, c1, r2, c2) {
    swapGems(grid, r1, c1, r2, c2);
    const matches = findMatches(grid, COLS, ROWS);
    if (matches.size === 0) {
      swapGems(grid, r1, c1, r2, c2); // swap back
      audio.play('invalid');
      addFloat(
        GRID_X + c1 * GEM_SIZE + GEM_SIZE,
        GRID_Y + r1 * GEM_SIZE,
        'DAME!', '#FF4444', 18
      );
      return;
    }
    moves--;
    combo = 0;
    startProcessing();
  }

  // ── Processing pipeline ────────────────────────────────────
  function startProcessing() {
    phase = 'processing';
    phaseTimer = 0.08;
  }

  function processStep() {
    const matches = findMatches(grid, COLS, ROWS);
    if (matches.size === 0) {
      combo = 0;
      matchedSet = new Set();
      phase = 'idle';
      if (moves <= 0) {
        setTimeout(() => endGame(), 400);
      } else if (!hasValidMove(grid, COLS, ROWS)) {
        addFloat(width / 2, height / 2, 'RESHUFFLING...', '#AAF', 20);
        setTimeout(() => {
          grid = createBoard(COLS, ROWS);
          phase = 'idle';
        }, 800);
      }
      return;
    }

    matchedSet = matches;
    combo++;
    const pts = matches.size * 10 * combo;
    score += pts;

    // Combo effects
    const cx = width / 2;
    const cy = GRID_Y + ROWS * GEM_SIZE / 2;

    if (combo >= 5) {
      addFloat(cx, cy - 30, POWER_MSGS[Math.floor(Math.random() * POWER_MSGS.length)], '#FFD700', 30);
      flash(1);
      shake(12);
      audio.play('big');
    } else if (combo >= 2) {
      addFloat(cx, cy - 20, `${combo}x ${COMBO_MSGS[Math.min(combo - 1, COMBO_MSGS.length - 1)]}`, '#FF8C00', 26);
      shake(6 * combo);
      audio.play('combo');
    } else {
      audio.play('match');
    }

    // Particles at each matched cell
    for (const key of matches) {
      const [r, c] = key.split(',').map(Number);
      const { x, y } = gemCenter(r, c);
      addExplosion(x, y, grid[r][c], 8 + combo * 2);
    }

    // Score popup
    addFloat(cx, GRID_Y - 20, `+${pts}`, '#FFF', 20);
    bgPulse = 0.5;

    removeMatches(grid, matches);
    applyGravity(grid, COLS, ROWS);
    fillBoard(grid, COLS, ROWS);

    // Check win
    if (score >= TARGET_SCORE) {
      phase = 'win';
      if (score > highScore) { highScore = score; localStorage.setItem('dbcHighScore', highScore); }
      audio.play('win');
      return;
    }

    phaseTimer = 0.38;
  }

  // ── Game state ─────────────────────────────────────────────
  function endGame() {
    phase = 'gameover';
    if (score > highScore) { highScore = score; localStorage.setItem('dbcHighScore', highScore); }
    audio.play('lose');
  }

  function restartGame() {
    grid = createBoard(COLS, ROWS);
    phase = 'idle';
    score = 0;
    moves = MAX_MOVES;
    combo = 0;
    selected = null;
    matchedSet = new Set();
    particles = [];
    floatTexts = [];
    screenfx = 0;
  }

  // ── Render ─────────────────────────────────────────────────
  function render(dt, now) {
    // Background
    if (bgImg.complete && bgImg.naturalWidth > 0) {
      ctx.drawImage(bgImg, 0, 0, width, height);
    } else {
      const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
      bgGrad.addColorStop(0, '#0a0050');
      bgGrad.addColorStop(0.5, '#200050');
      bgGrad.addColorStop(1, '#000020');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);
    }

    // BG pulse overlay
    if (bgPulse > 0) {
      ctx.fillStyle = `rgba(255,200,50,${bgPulse * 0.15})`;
      ctx.fillRect(0, 0, width, height);
      bgPulse = Math.max(0, bgPulse - dt * 2);
    }

    // Shake transform
    const sx = shakeX > 0.1 ? (Math.random() - 0.5) * shakeX * 8 : 0;
    const sy = shakeY > 0.1 ? (Math.random() - 0.5) * shakeY * 8 : 0;
    shakeX = Math.max(0, shakeX - dt * 15);
    shakeY = Math.max(0, shakeY - dt * 15);

    ctx.save();
    ctx.translate(sx, sy);

    drawHUD();
    drawGrid(now);
    drawParticles(dt);
    drawFloatTexts(dt);

    ctx.restore();

    // Screen flash
    if (screenfx > 0) {
      ctx.fillStyle = `rgba(255,240,100,${screenfx * 0.45})`;
      ctx.fillRect(0, 0, width, height);
      screenfx = Math.max(0, screenfx - dt * 3);
    }

    if (phase === 'gameover') drawGameover();
    if (phase === 'win') drawWin();
    if (phase === 'intro') drawIntro();
  }

  function drawHUD() {
    // Top panel
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    roundRect(ctx, 8, 8, width - 16, 78, 16);
    ctx.fill();

    ctx.strokeStyle = '#FFD700';
    ctx.lineWidth = 2;
    roundRect(ctx, 8, 8, width - 16, 78, 16);
    ctx.stroke();

    // Title
    ctx.fillStyle = '#FFD700';
    ctx.font = "bold 18px 'Bangers', 'Arial Black', sans-serif";
    ctx.textAlign = 'center';
    ctx.shadowBlur = 8; ctx.shadowColor = '#FF8C00';
    ctx.fillText('DRAGON BALL CRUSH', width / 2, 30);
    ctx.shadowBlur = 0;

    // Score
    ctx.font = "bold 14px sans-serif";
    ctx.fillStyle = '#AAF';
    ctx.textAlign = 'left';
    ctx.fillText('SCORE', 20, 52);
    ctx.fillStyle = '#FFF';
    ctx.font = "bold 20px sans-serif";
    ctx.fillText(score.toLocaleString(), 20, 72);

    // Target
    ctx.fillStyle = '#AAF';
    ctx.font = "bold 14px sans-serif";
    ctx.textAlign = 'center';
    ctx.fillText('TARGET', width / 2, 52);
    ctx.fillStyle = score >= TARGET_SCORE ? '#00FF88' : '#FFF';
    ctx.font = "bold 20px sans-serif";
    ctx.fillText(TARGET_SCORE.toLocaleString(), width / 2, 72);

    // Moves
    ctx.fillStyle = '#AAF';
    ctx.font = "bold 14px sans-serif";
    ctx.textAlign = 'right';
    ctx.fillText('MOVES', width - 20, 52);
    ctx.fillStyle = moves <= 5 ? '#FF4444' : '#FFF';
    ctx.font = "bold 20px sans-serif";
    ctx.fillText(moves, width - 20, 72);

    ctx.restore();

    // Progress bar
    ctx.save();
    const barX = 8, barY = 88, barW = width - 16, barH = 4;
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillRect(barX, barY, barW, barH);
    const prog = Math.min(score / TARGET_SCORE, 1);
    const barGrad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
    barGrad.addColorStop(0, '#FF8C00');
    barGrad.addColorStop(0.5, '#FFD700');
    barGrad.addColorStop(1, '#00FF88');
    ctx.fillStyle = barGrad;
    ctx.fillRect(barX, barY, barW * prog, barH);
    ctx.restore();
  }

  function drawGrid(now) {
    // Board background
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,30,0.5)';
    roundRect(ctx, GRID_X - 4, GRID_Y - 4, COLS * GEM_SIZE + 8, ROWS * GEM_SIZE + 8, 8);
    ctx.fill();

    // Grid lines
    ctx.strokeStyle = 'rgba(255,255,255,0.07)';
    ctx.lineWidth = 0.5;
    for (let r = 0; r <= ROWS; r++) {
      ctx.beginPath();
      ctx.moveTo(GRID_X, GRID_Y + r * GEM_SIZE);
      ctx.lineTo(GRID_X + COLS * GEM_SIZE, GRID_Y + r * GEM_SIZE);
      ctx.stroke();
    }
    for (let c = 0; c <= COLS; c++) {
      ctx.beginPath();
      ctx.moveTo(GRID_X + c * GEM_SIZE, GRID_Y);
      ctx.lineTo(GRID_X + c * GEM_SIZE, GRID_Y + ROWS * GEM_SIZE);
      ctx.stroke();
    }
    ctx.restore();

    const matchArr = [...matchedSet];
    const flashOn = (Math.floor(now * 8) % 2 === 0);

    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const gem = grid[r][c];
        if (gem === null) continue;

        const gx = GRID_X + c * GEM_SIZE;
        const gy = GRID_Y + r * GEM_SIZE;
        const key = `${r},${c}`;
        const isMatched = matchedSet.has(key);
        const isSel = selected && selected.r === r && selected.c === c;

        let alpha = 1;
        let glowExtra = 0;
        let pulse = 0;

        if (isMatched && flashOn) {
          alpha = 0.3;
          glowExtra = 20;
        }
        if (isSel) {
          pulse = Math.sin(now * 6) * 0.5 + 0.5;
          glowExtra = 10;
          // Selection ring
          ctx.save();
          ctx.strokeStyle = '#FFF';
          ctx.lineWidth = 2.5;
          ctx.shadowBlur = 12; ctx.shadowColor = '#FFD700';
          ctx.strokeRect(gx + 2, gy + 2, GEM_SIZE - 4, GEM_SIZE - 4);
          ctx.restore();
        }

        drawGem(ctx, gem, gx + 1, gy + 1, GEM_SIZE - 2, alpha, glowExtra, pulse);
      }
    }
  }

  function drawParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 320 * dt;
      p.life -= dt / p.maxLife;
      if (p.life <= 0) { particles.splice(i, 1); continue; }

      ctx.save();
      ctx.globalAlpha = p.life;
      ctx.shadowBlur = 10; ctx.shadowColor = p.color;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  function drawFloatTexts(dt) {
    for (let i = floatTexts.length - 1; i >= 0; i--) {
      const t = floatTexts[i];
      t.y += t.vy * dt;
      t.life -= dt / t.maxLife;
      if (t.life <= 0) { floatTexts.splice(i, 1); continue; }

      ctx.save();
      ctx.globalAlpha = Math.min(t.life * 2, 1);
      ctx.shadowBlur = 12; ctx.shadowColor = t.color;
      ctx.fillStyle = t.color;
      ctx.strokeStyle = 'rgba(0,0,0,0.7)';
      ctx.lineWidth = 3;
      ctx.font = `bold ${t.size}px 'Bangers', 'Arial Black', sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillText(t.text, t.x, t.y);
      ctx.restore();
    }
  }

  function drawOverlay(r, g2, b, a, title, sub, btnLabel) {
    ctx.fillStyle = `rgba(${r},${g2},${b},${a})`;
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    ctx.fillStyle = 'rgba(0,0,30,0.85)';
    roundRect(ctx, 30, height / 2 - 130, width - 60, 260, 20);
    ctx.fill();
    ctx.strokeStyle = '#FFD700';
    ctx.lineWidth = 3;
    roundRect(ctx, 30, height / 2 - 130, width - 60, 260, 20);
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.textAlign = 'center';
    ctx.shadowBlur = 20; ctx.shadowColor = '#FFD700';
    ctx.fillStyle = '#FFD700';
    ctx.font = `bold 42px 'Bangers', 'Arial Black', sans-serif`;
    ctx.fillText(title, width / 2, height / 2 - 75);

    ctx.shadowBlur = 0;
    ctx.fillStyle = '#FFF';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText(sub, width / 2, height / 2 - 30);

    ctx.fillStyle = '#AAF';
    ctx.font = 'bold 14px sans-serif';
    ctx.fillText(`SCORE: ${score.toLocaleString()}`, width / 2, height / 2 + 5);
    ctx.fillText(`BEST: ${highScore.toLocaleString()}`, width / 2, height / 2 + 28);
    ctx.restore();

    // Button
    const bx = width / 2 - 100, by = height / 2 + 58;
    const hov = g.pointer && inRect(g.pointer, bx, by, 200, 44);
    ctx.save();
    ctx.shadowBlur = hov ? 20 : 10; ctx.shadowColor = '#FF8C00';
    const btnGrad = ctx.createLinearGradient(bx, by, bx + 200, by + 44);
    btnGrad.addColorStop(0, hov ? '#FF8C00' : '#FF6600');
    btnGrad.addColorStop(1, hov ? '#FFD700' : '#FF8C00');
    ctx.fillStyle = btnGrad;
    roundRect(ctx, bx, by, 200, 44, 12);
    ctx.fill();
    ctx.fillStyle = '#000';
    ctx.font = `bold 18px 'Bangers', 'Arial Black', sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText(btnLabel, width / 2, by + 28);
    ctx.restore();
  }

  function drawGameover() {
    drawOverlay(20, 0, 0, 0.75, 'GAME OVER', 'あなたは負けた！MATA NE!', '▶  PLAY AGAIN');
  }

  function drawWin() {
    drawOverlay(0, 10, 30, 0.75, 'VICTORY!!!', 'SUGOI! YOU ARE THE STRONGEST!!', '▶  PLAY AGAIN');
    // Fireworks
    const t = Date.now() * 0.001;
    for (let i = 0; i < 5; i++) {
      const nx = (Math.sin(t * 1.3 + i * 1.26) * 0.4 + 0.5) * width;
      const ny = (Math.sin(t * 0.9 + i * 0.9) * 0.3 + 0.3) * height;
      ctx.save();
      ctx.shadowBlur = 30; ctx.shadowColor = GEM_COLORS[i % GEM_COLORS.length];
      ctx.fillStyle = GEM_COLORS[i % GEM_COLORS.length];
      ctx.beginPath();
      ctx.arc(nx, ny, 4 + Math.sin(t * 4 + i) * 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  function drawIntro() {
    ctx.save();
    ctx.fillStyle = `rgba(0,0,20,${Math.min(introTimer / 1.5, 1) * 0.8})`;
    ctx.fillRect(0, 0, width, height);
    const a = Math.min((1.5 - introTimer) / 0.5, 1);
    ctx.globalAlpha = a;
    ctx.shadowBlur = 30; ctx.shadowColor = '#FF8C00';
    ctx.fillStyle = '#FFD700';
    ctx.font = `bold 52px 'Bangers', 'Arial Black', sans-serif`;
    ctx.textAlign = 'center';
    ctx.fillText('DRAGON BALL', width / 2, height / 2 - 20);
    ctx.shadowBlur = 10; ctx.shadowColor = '#FFD700';
    ctx.fillStyle = '#FF8C00';
    ctx.font = `bold 36px 'Bangers', 'Arial Black', sans-serif`;
    ctx.fillText('CRUSH!', width / 2, height / 2 + 30);
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // ── Utility: rounded rect ─────────────────────────────────
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  // Cursor
  g.canvas.style.cursor = 'pointer';

  // ── Game Loop ─────────────────────────────────────────────
  g.loop((dt, now) => {
    dt = Math.min(dt, 0.05);

    handleInput(dt);

    if (phase === 'processing') {
      phaseTimer -= dt;
      if (phaseTimer <= 0) processStep();
    }

    render(dt, now);
  });

  // Start with intro
  phase = 'intro';

}, { preset: 'portrait' });
