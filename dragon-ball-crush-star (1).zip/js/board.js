export const GEM_TYPES = 6;

export function makeGem(type = null) {
  return type !== null ? type : Math.floor(Math.random() * GEM_TYPES);
}

export function createBoard(cols, rows) {
  const grid = [];
  for (let r = 0; r < rows; r++) {
    grid[r] = [];
    for (let c = 0; c < cols; c++) {
      let gem;
      do {
        gem = Math.floor(Math.random() * GEM_TYPES);
      } while (
        (c >= 2 && grid[r][c - 1] === gem && grid[r][c - 2] === gem) ||
        (r >= 2 && grid[r - 1][c] === gem && grid[r - 2][c] === gem)
      );
      grid[r][c] = gem;
    }
  }
  return grid;
}

export function findMatches(grid, cols, rows) {
  const matched = new Set();
  // Horizontal
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols - 2; c++) {
      const gem = grid[r][c];
      if (gem === null) continue;
      if (gem === grid[r][c + 1] && gem === grid[r][c + 2]) {
        let end = c + 3;
        while (end < cols && grid[r][end] === gem) end++;
        for (let i = c; i < end; i++) matched.add(`${r},${i}`);
        c = end - 1;
      }
    }
  }
  // Vertical
  for (let c = 0; c < cols; c++) {
    for (let r = 0; r < rows - 2; r++) {
      const gem = grid[r][c];
      if (gem === null) continue;
      if (gem === grid[r + 1][c] && gem === grid[r + 2][c]) {
        let end = r + 3;
        while (end < rows && grid[end][c] === gem) end++;
        for (let i = r; i < end; i++) matched.add(`${i},${c}`);
        r = end - 1;
      }
    }
  }
  return matched;
}

export function removeMatches(grid, matched) {
  for (const key of matched) {
    const [r, c] = key.split(',').map(Number);
    grid[r][c] = null;
  }
}

export function applyGravity(grid, cols, rows) {
  for (let c = 0; c < cols; c++) {
    let writeRow = rows - 1;
    for (let r = rows - 1; r >= 0; r--) {
      if (grid[r][c] !== null) {
        grid[writeRow][c] = grid[r][c];
        if (writeRow !== r) grid[r][c] = null;
        writeRow--;
      }
    }
    while (writeRow >= 0) {
      grid[writeRow][c] = null;
      writeRow--;
    }
  }
}

export function fillBoard(grid, cols, rows) {
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (grid[r][c] === null) {
        grid[r][c] = Math.floor(Math.random() * GEM_TYPES);
      }
    }
  }
}

export function swapGems(grid, r1, c1, r2, c2) {
  const tmp = grid[r1][c1];
  grid[r1][c1] = grid[r2][c2];
  grid[r2][c2] = tmp;
}

export function isAdjacent(r1, c1, r2, c2) {
  return Math.abs(r1 - r2) + Math.abs(c1 - c2) === 1;
}

export function hasValidMove(grid, cols, rows) {
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      // Try swap right
      if (c + 1 < cols) {
        swapGems(grid, r, c, r, c + 1);
        const m = findMatches(grid, cols, rows);
        swapGems(grid, r, c, r, c + 1);
        if (m.size > 0) return true;
      }
      // Try swap down
      if (r + 1 < rows) {
        swapGems(grid, r, c, r + 1, c);
        const m = findMatches(grid, cols, rows);
        swapGems(grid, r, c, r + 1, c);
        if (m.size > 0) return true;
      }
    }
  }
  return false;
}
