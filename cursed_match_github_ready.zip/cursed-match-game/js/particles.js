// Particle system for match explosions, glow effects, combos

export class ParticleSystem {
  constructor(container) {
    this.container = container;
    this.canvas = document.createElement('canvas');
    this.canvas.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:15;';
    this.container.appendChild(this.canvas);
    this.ctx = this.canvas.getContext('2d');
    this.particles = [];
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  /** Emit particles at screen position for a matched tile */
  emitMatch(x, y, color, count = 12) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.random() * Math.PI * 2);
      const speed = 1.5 + Math.random() * 3.5;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 1,
        life: 1,
        decay: 0.02 + Math.random() * 0.025,
        size: 3 + Math.random() * 6,
        color,
        type: Math.random() > 0.5 ? 'circle' : 'star',
        rot: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.2,
      });
    }
  }

  /** Big explosion for special matches */
  emitExplosion(x, y, color, count = 30) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.random() * Math.PI * 2);
      const speed = 2 + Math.random() * 6;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 2,
        life: 1,
        decay: 0.012 + Math.random() * 0.02,
        size: 4 + Math.random() * 10,
        color,
        type: i % 3 === 0 ? 'spark' : 'circle',
        rot: 0, rotSpeed: 0,
        trail: [],
      });
    }
  }

  /** Floating score text */
  emitScoreText(x, y, text, color = '#fbbf24') {
    this.particles.push({
      x, y,
      vx: 0,
      vy: -1.5,
      life: 1,
      decay: 0.018,
      size: 22,
      color,
      type: 'text',
      text,
    });
  }

  /** Kanji burst effect */
  emitKanji(x, y, kanji, color) {
    this.particles.push({
      x, y,
      vx: (Math.random() - 0.5) * 2,
      vy: -2 - Math.random() * 2,
      life: 1,
      decay: 0.015,
      size: 28 + Math.random() * 16,
      color,
      type: 'text',
      text: kanji,
    });
  }

  update() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= p.decay;
      if (p.life <= 0) { this.particles.splice(i, 1); continue; }

      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.08; // gravity
      if (p.rotSpeed) p.rot += p.rotSpeed;

      const alpha = Math.max(0, p.life);
      this.ctx.save();
      this.ctx.globalAlpha = alpha;

      if (p.type === 'circle') {
        this.ctx.beginPath();
        this.ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
        this.ctx.fillStyle = p.color;
        this.ctx.shadowColor = p.color;
        this.ctx.shadowBlur = p.size * 2;
        this.ctx.fill();
      } else if (p.type === 'star') {
        drawStar(this.ctx, p.x, p.y, p.size * p.life * 0.5, p.size * p.life, 4, p.rot, p.color);
      } else if (p.type === 'spark') {
        this.ctx.beginPath();
        this.ctx.moveTo(p.x, p.y);
        this.ctx.lineTo(p.x - p.vx * 4, p.y - p.vy * 4);
        this.ctx.strokeStyle = p.color;
        this.ctx.lineWidth = p.size * 0.3;
        this.ctx.shadowColor = p.color;
        this.ctx.shadowBlur = 8;
        this.ctx.stroke();
      } else if (p.type === 'text') {
        this.ctx.font = `bold ${p.size}px Rajdhani, sans-serif`;
        this.ctx.fillStyle = p.color;
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.shadowColor = p.color;
        this.ctx.shadowBlur = 15;
        this.ctx.fillText(p.text, p.x, p.y);
      }

      this.ctx.restore();
    }
  }

  clear() { this.particles = []; }
}

function drawStar(ctx, cx, cy, innerR, outerR, points, rotation, color) {
  ctx.save();
  ctx.beginPath();
  ctx.translate(cx, cy);
  ctx.rotate(rotation);
  for (let i = 0; i < points * 2; i++) {
    const r = i % 2 === 0 ? outerR : innerR;
    const angle = (i / (points * 2)) * Math.PI * 2;
    if (i === 0) ctx.moveTo(r * Math.cos(angle), r * Math.sin(angle));
    else ctx.lineTo(r * Math.cos(angle), r * Math.sin(angle));
  }
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = outerR * 2;
  ctx.fill();
  ctx.restore();
}
