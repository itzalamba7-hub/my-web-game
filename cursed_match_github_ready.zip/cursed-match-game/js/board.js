// Board logic: grid, matching, gravity, swapping
import { NUM_TYPES } from './tiles.js';

export const GRID_COLS = 7;
export const GRID_ROWS = 7;

export class Board {
  constructor(cols = GRID_COLS, rows = GRID_ROWS) {
    this.cols = cols;
    this.rows = rows;
    this.grid = [];
    this.init();
  }

  init() {
    do {
      this.grid = this._createGrid();
    } while (this._findMatches().length > 0 || !this._hasMoves());
  }

  _createGrid() {
    const g = [];
    for (let r = 0; r < this.rows; r++) {
      g[r] = [];
      for (let c = 0; c < this.cols; c++) {
        g[r][c] = this._safeRandom(g, r, c);
      }
    }
    return g;
  }

  _safeRandom(g, r, c) {
    const forbidden = new Set();
    if (c >= 2 && g[r][c-1] === g[r][c-2]) forbidden.add(g[r][c-1]);
    if (r >= 2 && g[r-1] && g[r-1][c] === g[r-2][c]) forbidden.add(g[r-1][c]);
    const available = Array.from({length: NUM_TYPES}, (_, i) => i).filter(t => !forbidden.has(t));
    return available[Math.floor(Math.random() * available.length)];
  }

  get(r, c) { return this.grid[r]?.[c] ?? -1; }
  set(r, c, val) { if (this.grid[r]) this.grid[r][c] = val; }

  isValid(r, c) { return r >= 0 && r < this.rows && c >= 0 && c < this.cols; }

  swap(r1, c1, r2, c2) {
    const tmp = this.grid[r1][c1];
    this.grid[r1][c1] = this.grid[r2][c2];
    this.grid[r2][c2] = tmp;
  }

  /** Returns array of arrays of {r,c} positions that form matches */
  _findMatches() {
    const matched = new Set();
    // Horizontal
    for (let r = 0; r < this.rows; r++) {
      let streak = 1;
      for (let c = 1; c <= this.cols; c++) {
        if (c < this.cols && this.grid[r][c] === this.grid[r][c-1] && this.grid[r][c] !== -1) {
          streak++;
        } else {
          if (streak >= 3) {
            for (let k = c - streak; k < c; k++) matched.add(`${r},${k}`);
          }
          streak = 1;
        }
      }
    }
    // Vertical
    for (let c = 0; c < this.cols; c++) {
      let streak = 1;
      for (let r = 1; r <= this.rows; r++) {
        if (r < this.rows && this.grid[r][c] === this.grid[r-1][c] && this.grid[r][c] !== -1) {
          streak++;
        } else {
          if (streak >= 3) {
            for (let k = r - streak; k < r; k++) matched.add(`${k},${c}`);
          }
          streak = 1;
        }
      }
    }
    return [...matched].map(s => { const [r,c] = s.split(',').map(Number); return {r,c}; });
  }

  findMatches() { return this._findMatches(); }

  /** Remove matched tiles (set to -1) */
  clearMatches(matches) {
    for (const {r, c} of matches) this.grid[r][c] = -1;
  }

  /** Apply gravity: tiles fall down to fill gaps. Returns array of {r, c, from} */
  applyGravity() {
    const moves = [];
    for (let c = 0; c < this.cols; c++) {
      let writeRow = this.rows - 1;
      for (let r = this.rows - 1; r >= 0; r--) {
        if (this.grid[r][c] !== -1) {
          if (r !== writeRow) {
            moves.push({ r: writeRow, c, from: r, tile: this.grid[r][c] });
            this.grid[writeRow][c] = this.grid[r][c];
            this.grid[r][c] = -1;
          }
          writeRow--;
        }
      }
    }
    return moves;
  }

  /** Fill empty (-1) cells with new random tiles */
  refill() {
    const newTiles = [];
    for (let c = 0; c < this.cols; c++) {
      for (let r = 0; r < this.rows; r++) {
        if (this.grid[r][c] === -1) {
          this.grid[r][c] = Math.floor(Math.random() * NUM_TYPES);
          newTiles.push({ r, c, tile: this.grid[r][c] });
        }
      }
    }
    return newTiles;
  }

  areAdjacent(r1,c1,r2,c2) {
    return (Math.abs(r1-r2) + Math.abs(c1-c2)) === 1;
  }

  swapWouldMatch(r1,c1,r2,c2) {
    this.swap(r1,c1,r2,c2);
    const matches = this._findMatches();
    this.swap(r1,c1,r2,c2);
    return matches.length > 0;
  }

  _hasMoves() {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (c + 1 < this.cols && this.swapWouldMatch(r,c,r,c+1)) return true;
        if (r + 1 < this.rows && this.swapWouldMatch(r,c,r+1,c)) return true;
      }
    }
    return false;
  }

  hasMoves() { return this._hasMoves(); }

  /** Shuffle board when no moves available */
  shuffle() {
    const all = this.grid.flat().filter(t => t !== -1);
    for (let i = all.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i+1));
      [all[i], all[j]] = [all[j], all[i]];
    }
    let idx = 0;
    for (let r = 0; r < this.rows; r++)
      for (let c = 0; c < this.cols; c++)
        if (this.grid[r][c] !== -1) this.grid[r][c] = all[idx++];
  }

  /** Check if a cell is part of a specific match group (5+, L, T shapes) */
  getMatchType(matches) {
    if (matches.length >= 5) return 'bomb';
    if (matches.length >= 4) return 'special';
    return 'normal';
  }
}
