// Core game controller
import { Board } from './board.js';
import { Renderer } from './renderer.js';
import { ParticleSystem } from './particles.js';
import { Audio } from './audio.js';
import { TILE_TYPES } from './tiles.js';
import { LEVELS } from './levels.js';

export class Game {
  constructor() {
    this.canvas = document.getElementById('game-canvas');
    this.particles = new ParticleSystem(document.getElementById('particle-layer'));
    this.state = 'idle'; // idle | playing | animating | complete | gameover
    this.currentLevel = 0;
    this.score = 0;
    this.moves = 0;
    this.combo = 0;
    this.selectedCell = null;
    this.hoveredCell = null;
    this.animFrame = null;
    this.lastTime = 0;
    this.time = 0;
    this._bindUI();
  }

  _bindUI() {
    document.getElementById('btn-start').addEventListener('click', () => {
      Audio.select();
      this.startLevel(0);
    });
    document.getElementById('btn-next').addEventListener('click', () => {
      Audio.select();
      this.startLevel(this.currentLevel + 1);
    });
    document.getElementById('btn-retry').addEventListener('click', () => {
      Audio.select();
      this.startLevel(this.currentLevel);
    });
    document.getElementById('btn-menu').addEventListener('click', () => {
      Audio.select();
      this.showScreen('screen-start');
      this._hideHUD();
      Audio.stopBGM();
    });

    // Canvas input
    this.canvas.addEventListener('pointerdown', e => this._onPointerDown(e));
    this.canvas.addEventListener('pointermove', e => this._onPointerMove(e));
    this.canvas.addEventListener('pointerup', e => this._onPointerUp(e));
    this.canvas.addEventListener('pointerleave', () => { this.hoveredCell = null; this.dragStart = null; });
  }

  startLevel(levelIndex) {
    const maxLevel = LEVELS.length - 1;
    if (levelIndex > maxLevel) levelIndex = maxLevel;
    this.currentLevel = levelIndex;
    const lvl = LEVELS[levelIndex];

    this.board = new Board(lvl.cols, lvl.rows);
    this.renderer = new Renderer(this.canvas, this.board);
    this.score = 0;
    this.moves = lvl.moves;
    this.combo = 0;
    this.selectedCell = null;
    this.hoveredCell = null;
    this.dragStart = null;
    this.state = 'playing';

    this.hideAllScreens();
    this._showHUD();
    this._updateHUD();

    document.getElementById('objective-text').textContent = `✦ ${lvl.title} ✦ — ${lvl.objective}`;
    document.getElementById('objective-bar').classList.remove('hidden');

    Audio.startBGM();

    if (this.animFrame) cancelAnimationFrame(this.animFrame);
    this.animFrame = requestAnimationFrame(t => this._loop(t));
  }

  _loop(timestamp) {
    const dt = timestamp - this.lastTime;
    this.lastTime = timestamp;
    this.time = timestamp;

    this.particles.update();
    this.renderer.render(this.selectedCell, this.hoveredCell, this.time);

    this.animFrame = requestAnimationFrame(t => this._loop(t));
  }

  _onPointerDown(e) {
    if (this.state !== 'playing') return;
    e.preventDefault();
    const { x, y } = this._getEventPos(e);
    const cell = this.renderer.screenToCell(x, y);
    if (!cell) return;
    this.dragStart = { x, y, cell };
    if (this.selectedCell && this.board.areAdjacent(cell.r, cell.c, this.selectedCell.r, this.selectedCell.c)) {
      this._trySwap(this.selectedCell, cell);
    } else {
      Audio.select();
      this.selectedCell = cell;
    }
  }

  _onPointerMove(e) {
    if (this.state !== 'playing') return;
    const { x, y } = this._getEventPos(e);
    this.hoveredCell = this.renderer.screenToCell(x, y);

    // Drag detection
    if (this.dragStart) {
      const dx = x - this.dragStart.x;
      const dy = y - this.dragStart.y;
      const ts = this.renderer.tileSize;
      if (Math.abs(dx) > ts * 0.35 || Math.abs(dy) > ts * 0.35) {
        const dc = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : -1) : 0;
        const dr = Math.abs(dy) >= Math.abs(dx) ? (dy > 0 ? 1 : -1) : 0;
        const target = { r: this.dragStart.cell.r + dr, c: this.dragStart.cell.c + dc };
        if (this.board.isValid(target.r, target.c)) {
          this._trySwap(this.dragStart.cell, target);
        }
        this.dragStart = null;
      }
    }
  }

  _onPointerUp(e) {
    this.dragStart = null;
  }

  _getEventPos(e) {
    const rect = this.canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: clientX, y: clientY };
  }

  _trySwap(cell1, cell2) {
    if (this.state !== 'playing') return;
    if (!this.board.areAdjacent(cell1.r, cell1.c, cell2.r, cell2.c)) {
      this.selectedCell = cell2;
      return;
    }

    if (!this.board.swapWouldMatch(cell1.r, cell1.c, cell2.r, cell2.c)) {
      // Invalid swap: animate wiggle
      Audio.invalid();
      this.renderer.shake(6);
      this.selectedCell = null;
      return;
    }

    this.state = 'animating';
    this.selectedCell = null;
    Audio.swap();

    // Perform the swap
    this.board.swap(cell1.r, cell1.c, cell2.r, cell2.c);
    this.moves--;
    this._updateHUD();
    this.combo = 0;

    this.renderer.addSwapAnim(cell1.r, cell1.c, cell2.r, cell2.c, () => {
      this._processMatches();
    });
  }

  async _processMatches() {
    const matches = this.board.findMatches();
    if (matches.length === 0) {
      this.state = 'playing';
      this._checkGameOver();
      return;
    }

    this.combo++;
    const matchType = this.board.getMatchType(matches);

    // Emit particle effects & sounds
    const matchedTiles = matches.map(({r,c}) => ({ r, c, tile: this.board.get(r,c) }));
    if (matchType === 'bomb') {
      Audio.bigMatch();
    } else if (this.combo > 1) {
      Audio.combo(this.combo);
    } else {
      Audio.match();
    }

    // Score calculation
    const baseScore = matches.length * 50;
    const comboMult = 1 + (this.combo - 1) * 0.5;
    const matchBonus = matchType === 'bomb' ? 2 : matchType === 'special' ? 1.5 : 1;
    const earned = Math.round(baseScore * comboMult * matchBonus);
    this.score += earned;
    this._updateHUD();
    this._showCombo(this.combo, earned);

    // Animate match tiles out
    for (const {r, c, tile} of matchedTiles) {
      this.renderer.addMatchAnim(r, c, tile);

      // Particles
      const center = this.renderer.cellCenter(r, c);
      const tileInfo = TILE_TYPES[tile];
      if (tileInfo) {
        if (matchType === 'bomb') {
          this.particles.emitExplosion(center.x, center.y, tileInfo.glow, 25);
        } else {
          this.particles.emitMatch(center.x, center.y, tileInfo.glow, 10);
        }
      }
    }

    // Floating score
    if (matches.length > 0) {
      const midMatch = matchedTiles[Math.floor(matchedTiles.length / 2)];
      const center = this.renderer.cellCenter(midMatch.r, midMatch.c);
      this.particles.emitScoreText(center.x, center.y, `+${earned}`, '#fbbf24');
      if (this.combo > 1) {
        this.particles.emitKanji(center.x, center.y - 30, `${this.combo}連`, '#e879f9');
      }
    }

    // Clear matched, wait for animations
    this.board.clearMatches(matches);
    this.renderer.shake(matchType === 'bomb' ? 10 : 5);

    await this._wait(350);

    // Gravity
    const falls = this.board.applyGravity();
    for (const {r, c, from, tile} of falls) {
      this.renderer.addFallAnim(r, c, from, tile);
    }

    await this._wait(400);

    // Refill
    const newTiles = this.board.refill();
    for (const {r, c, tile} of newTiles) {
      this.renderer.addFallAnim(r, c, -4, tile);
    }

    await this._wait(300);

    // Check for chain matches
    this._processMatches();
  }

  _wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  _showCombo(combo, score) {
    const el = document.getElementById('combo-display');
    if (combo > 1) {
      el.textContent = `${combo}x COMBO! +${score}`;
      el.classList.remove('hidden');
      clearTimeout(this._comboTimeout);
      this._comboTimeout = setTimeout(() => el.classList.add('hidden'), 1500);
    } else {
      el.classList.add('hidden');
    }
  }

  _checkGameOver() {
    const lvl = LEVELS[this.currentLevel];
    if (this.score >= lvl.targetScore) {
      this._levelComplete();
      return;
    }
    if (!this.board.hasMoves()) {
      this.board.shuffle();
      this.particles.emitKanji(window.innerWidth / 2, window.innerHeight / 2, '再配置', '#60a5fa');
    }
    if (this.moves <= 0) {
      if (this.score >= lvl.targetScore) {
        this._levelComplete();
      } else {
        this._gameOver();
      }
    }
  }

  _levelComplete() {
    this.state = 'complete';
    Audio.levelUp();

    const lvl = LEVELS[this.currentLevel];
    // Stars
    const pct = this.score / lvl.targetScore;
    const stars = pct >= 1.5 ? 3 : pct >= 1.1 ? 2 : 1;
    document.getElementById('complete-score').textContent = this.score.toLocaleString();
    const starsRow = document.getElementById('stars-row');
    starsRow.innerHTML = '';
    for (let i = 0; i < 3; i++) {
      const s = document.createElement('span');
      s.textContent = i < stars ? '⭐' : '☆';
      s.style.opacity = i < stars ? '1' : '0.3';
      starsRow.appendChild(s);
    }
    document.getElementById('reward-icon').textContent = lvl.reward.icon;
    document.getElementById('reward-text').textContent = lvl.reward.text;

    // Celebratory particles
    for (let i = 0; i < 8; i++) {
      setTimeout(() => {
        const x = Math.random() * window.innerWidth;
        const y = Math.random() * window.innerHeight * 0.5;
        this.particles.emitExplosion(x, y, ['#fbbf24','#a855f7','#38bdf8','#34d399'][i%4], 20);
      }, i * 150);
    }

    setTimeout(() => this.showScreen('screen-levelcomplete'), 600);
  }

  _gameOver() {
    this.state = 'gameover';
    Audio.gameOver();
    Audio.stopBGM();
    document.getElementById('go-score').textContent = this.score.toLocaleString();
    setTimeout(() => this.showScreen('screen-gameover'), 500);
  }

  _updateHUD() {
    document.getElementById('hud-score').textContent = this.score.toLocaleString();
    document.getElementById('hud-level').textContent = this.currentLevel + 1;
    const movesEl = document.getElementById('hud-moves');
    movesEl.textContent = this.moves;
    movesEl.classList.toggle('moves-low', this.moves <= 5);
  }

  _showHUD() {
    document.getElementById('hud').classList.remove('hidden');
    document.getElementById('objective-bar').classList.remove('hidden');
  }

  _hideHUD() {
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('objective-bar').classList.add('hidden');
  }

  showScreen(id) {
    this.hideAllScreens();
    document.getElementById(id).classList.add('active');
  }

  hideAllScreens() {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  }
}
