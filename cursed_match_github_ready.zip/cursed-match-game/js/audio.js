// Audio system using Web Audio API — procedural sound synthesis

let ctx = null;

function getCtx() {
  if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function playTone(freq, type, duration, gain = 0.3, delay = 0) {
  try {
    const ac = getCtx();
    const osc = ac.createOscillator();
    const gainNode = ac.createGain();
    osc.connect(gainNode);
    gainNode.connect(ac.destination);
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ac.currentTime + delay);
    gainNode.gain.setValueAtTime(0, ac.currentTime + delay);
    gainNode.gain.linearRampToValueAtTime(gain, ac.currentTime + delay + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + delay + duration);
    osc.start(ac.currentTime + delay);
    osc.stop(ac.currentTime + delay + duration + 0.05);
  } catch(e) {}
}

function playNoise(duration, gain = 0.2, delay = 0) {
  try {
    const ac = getCtx();
    const bufLen = ac.sampleRate * duration;
    const buf = ac.createBuffer(1, bufLen, ac.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < bufLen; i++) data[i] = Math.random() * 2 - 1;
    const src = ac.createBufferSource();
    src.buffer = buf;
    const gainNode = ac.createGain();
    gainNode.gain.setValueAtTime(gain, ac.currentTime + delay);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + delay + duration);
    src.connect(gainNode);
    gainNode.connect(ac.destination);
    src.start(ac.currentTime + delay);
  } catch(e) {}
}

export const Audio = {
  match() {
    // Satisfying "ping" chord
    playTone(523, 'sine', 0.25, 0.25);
    playTone(659, 'sine', 0.25, 0.2, 0.05);
    playTone(784, 'sine', 0.3, 0.15, 0.1);
  },

  bigMatch() {
    playTone(440, 'sine', 0.1, 0.3);
    playTone(554, 'sine', 0.15, 0.3, 0.07);
    playTone(659, 'sine', 0.2, 0.3, 0.14);
    playTone(880, 'sine', 0.4, 0.35, 0.21);
    playNoise(0.1, 0.15, 0.2);
  },

  combo(n) {
    // Higher pitch for higher combos
    const base = 300 + n * 80;
    playTone(base, 'sine', 0.15, 0.4);
    playTone(base * 1.5, 'triangle', 0.2, 0.25, 0.08);
    playTone(base * 2, 'sine', 0.25, 0.2, 0.16);
  },

  swap() {
    playTone(400, 'sine', 0.08, 0.15);
    playTone(500, 'sine', 0.08, 0.12, 0.04);
  },

  invalid() {
    playTone(200, 'sawtooth', 0.15, 0.2);
    playTone(180, 'sawtooth', 0.15, 0.15, 0.08);
  },

  levelUp() {
    const notes = [523, 659, 784, 1046, 1318];
    notes.forEach((f, i) => playTone(f, 'sine', 0.35, 0.3, i * 0.1));
    setTimeout(() => playTone(2093, 'sine', 0.6, 0.4), 550);
  },

  gameOver() {
    const notes = [523, 466, 415, 370, 330];
    notes.forEach((f, i) => playTone(f, 'sawtooth', 0.3, 0.2, i * 0.18));
  },

  select() {
    playTone(600, 'sine', 0.1, 0.2);
  },

  // BGM: generates a looping cursed ambient track using oscillators
  _bgmPlaying: false,
  _bgmNodes: [],

  startBGM() {
    if (this._bgmPlaying) return;
    this._bgmPlaying = true;
    this._scheduleBGM();
  },

  stopBGM() {
    this._bgmPlaying = false;
    this._bgmNodes.forEach(n => { try { n.stop(); } catch(e) {} });
    this._bgmNodes = [];
  },

  _scheduleBGM() {
    if (!this._bgmPlaying) return;
    try {
      const ac = getCtx();
      // Dark ambient drone
      const playDrone = (freq, dur, gain) => {
        const osc = ac.createOscillator();
        const gainNode = ac.createGain();
        const filter = ac.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 800;
        osc.type = 'sawtooth';
        osc.frequency.value = freq;
        osc.connect(gainNode);
        gainNode.connect(filter);
        filter.connect(ac.destination);
        gainNode.gain.setValueAtTime(0, ac.currentTime);
        gainNode.gain.linearRampToValueAtTime(gain, ac.currentTime + 1);
        gainNode.gain.linearRampToValueAtTime(gain * 0.7, ac.currentTime + dur - 1);
        gainNode.gain.linearRampToValueAtTime(0, ac.currentTime + dur);
        osc.start(ac.currentTime);
        osc.stop(ac.currentTime + dur);
        this._bgmNodes.push(osc);
      };

      // Pentatonic arpeggio for JJK feel
      const scale = [110, 130.8, 164.8, 196, 220, 261.6, 329.6];
      const beatLen = 0.45;
      const pattern = [0, 2, 4, 3, 5, 4, 2, 0, 1, 3, 5, 6, 5, 3, 1, 0];

      // Drone
      playDrone(55, 16, 0.04);
      playDrone(82.4, 16, 0.025);

      // Melody
      pattern.forEach((note, i) => {
        const freq = scale[note] * 2;
        playTone(freq, 'triangle', beatLen * 0.7, 0.06, i * beatLen);
      });

      // Schedule next loop
      const loopLen = pattern.length * beatLen * 1000;
      this._bgmTimeout = setTimeout(() => this._scheduleBGM(), loopLen);
    } catch(e) {}
  }
};
