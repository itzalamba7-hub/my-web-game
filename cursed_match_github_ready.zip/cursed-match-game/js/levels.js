// Level definitions for Cursed Match

const LEVEL_REWARDS = [
  { icon: '⚡', text: 'Cursed Energy Boost!' },
  { icon: '👁', text: 'Cursed Spirit Tamed!' },
  { icon: '📜', text: 'Ancient Talisman Found!' },
  { icon: '✦', text: 'Black Flash Unlocked!' },
  { icon: '∞', text: 'Limitless Activated!' },
  { icon: '💜', text: 'Purple Void Achieved!' },
  { icon: '✋', text: "Sukuna's Finger Claimed!" },
  { icon: '🌀', text: 'Domain Expansion Mastered!' },
  { icon: '⭐', text: 'Jujutsu Sorcerer Rank Up!' },
  { icon: '🔮', text: 'Reverse Cursed Technique!' },
];

export const LEVELS = Array.from({length: 20}, (_, i) => {
  const level = i + 1;
  const targetScore = 500 + level * 300 + Math.pow(level, 1.5) * 100;
  const moves = Math.max(15, 32 - Math.floor(level * 0.8));
  const cols = level <= 3 ? 6 : level <= 8 ? 7 : 8;
  const rows = level <= 3 ? 6 : level <= 8 ? 7 : 8;
  const reward = LEVEL_REWARDS[i % LEVEL_REWARDS.length];

  return {
    level,
    targetScore: Math.round(targetScore),
    moves,
    cols: Math.min(cols, 8),
    rows: Math.min(rows, 8),
    reward,
    objective: `Score ${Math.round(targetScore).toLocaleString()} pts in ${moves} moves`,
    title: getLevelTitle(level),
  };
});

function getLevelTitle(n) {
  const titles = [
    'The Cursed Womb',
    'Detention Center Raid',
    'The Origin of Obedience',
    'Fearsome Womb',
    'Assault',
    'Kyoto Sister School Exchange',
    'Domain of Mutual Love',
    'Hidden Inventory',
    "Premature Death",
    'Shibuya Incident',
    'The Catastrophe That Lies Before Us',
    'Reverse Cursed Technique',
    'Perfect Preparation',
    'Tombs of the Star Corridor',
    'Thunderclap',
    'Bath',
    'Black Box',
    'Execution',
    'The Cursed Child',
    'Inhuman Makyo Shinjuku Showdown',
  ];
  return titles[(n - 1) % titles.length];
}
