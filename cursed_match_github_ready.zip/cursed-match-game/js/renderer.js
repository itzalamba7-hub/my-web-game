// Canvas renderer for the match-3 board
import { drawTile, TILE_TYPES } from './tiles.js';

export class Renderer {
  constructor(canvas, board) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.board = board;
    this.tileSize = 70;
    this.offsetX = 0;
    this.offsetY = 0;
    this.animations = []; // active tile animations
    this.glowTimers = {}; // per-cell glow pulse
    this.shakeTimer = 0;
    this.shakeX = 0;
    this.shakeY = 0;
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    const maxW = Math.min(window.innerWidth - 16, 600);
    const maxH = window.innerHeight - 110;
    const cols = this.board.cols;
    const rows = this.board.rows;
    this.tileSize = Math.floor(Math.min(maxW / cols, maxH / rows));
    const boardW = this.tileSize * cols;
    const boardH = this.tileSize * rows;
    this.canvas.width = boardW;
    this.canvas.height = boardH;
    this.offsetX = Math.floor((window.innerWidth - boardW) / 2);
    this.offsetY = Math.floor((window.innerHeight - boardH) / 2) + 10;
    this.canvas.style.left = this.offsetX + 'px';
    this.canvas.style.top = this.offsetY + 'px';
  }

  /** Convert screen coords to grid cell */
  screenToCell(sx, sy) {
    const bx = sx - this.offsetX;
    const by = sy - this.offsetY;
    const c = Math.floor(bx / this.tileSize);
    const r = Math.floor(by / this.tileSize);
    if (r < 0 || r >= this.board.rows || c < 0 || c >= this.board.cols) return null;
    return { r, c };
  }

  /** Get screen center of a cell */
  cellCenter(r, c) {
    return {
      x: this.offsetX + c * this.tileSize + this.tileSize / 2,
      y: this.offsetY + r * this.tileSize + this.tileSize / 2,
    };
  }

  shake(intensity = 8) {
    this.shakeTimer = 20;
    this.shakeIntensity = intensity;
  }

  /** Add a tile fall animation */
  addFallAnim(r, c, fromRow, tile) {
    this.animations.push({
      type: 'fall',
      r, c, fromRow, tile,
      progress: 0, speed: 0.18,
    });
  }

  addSwapAnim(r1, c1, r2, c2, onDone) {
    this.animations.push({
      type: 'swap',
      r1, c1, r2, c2,
      progress: 0, speed: 0.15,
      onDone,
    });
  }

  addMatchAnim(r, c, tile) {
    this.animations.push({
      type: 'match',
      r, c, tile,
      progress: 0, speed: 0.1,
    });
  }

  isAnimating() {
    return this.animations.length > 0;
  }

  /** Main render call */
  render(selectedCell, hoveredCell, time) {
    const ctx = this.ctx;
    const ts = this.tileSize;

    // Screen shake
    let sx = 0, sy = 0;
    if (this.shakeTimer > 0) {
      const t = this.shakeTimer / 20;
      sx = (Math.random() - 0.5) * this.shakeIntensity * t;
      sy = (Math.random() - 0.5) * this.shakeIntensity * t;
      this.shakeTimer--;
    }

    ctx.save();
    ctx.translate(sx, sy);
    ctx.clearRect(-sx - 5, -sy - 5, this.canvas.width + 10, this.canvas.height + 10);

    // Board background
    this._drawBoardBg(ctx, ts);

    // Update & collect animated cells (don't draw normally)
    const animatedCells = new Set();
    const doneAnims = [];

    for (let i = this.animations.length - 1; i >= 0; i--) {
      const a = this.animations[i];
      a.progress = Math.min(1, a.progress + a.speed);

      if (a.type === 'fall') {
        animatedCells.add(`${a.r},${a.c}`);
        const startY = (a.fromRow - a.rows) * ts;
        const endY = a.r * ts;
        const eased = easeOutBounce(a.progress);
        const y = startY + (endY - startY) * eased;
        const glowPulse = a.progress < 0.3 ? a.progress / 0.3 : 0;
        drawTile(ctx, a.tile, a.c * ts, y, ts, { glowPulse });
        if (a.progress >= 1) doneAnims.push(i);
      } else if (a.type === 'swap') {
        animatedCells.add(`${a.r1},${a.c1}`);
        animatedCells.add(`${a.r2},${a.c2}`);
        const t = easeOutCubic(a.progress);
        const tile1 = this.board.get(a.r1, a.c1);
        const tile2 = this.board.get(a.r2, a.c2);
        const x1s = a.c1 * ts, y1s = a.r1 * ts;
        const x2s = a.c2 * ts, y2s = a.r2 * ts;
        const x1 = x1s + (x2s - x1s) * t;
        const y1 = y1s + (y2s - y1s) * t;
        const x2 = x2s + (x1s - x2s) * t;
        const y2 = y2s + (y1s - y2s) * t;
        const s = 1 + 0.12 * Math.sin(a.progress * Math.PI);
        if (tile1 !== -1) drawTile(ctx, tile1, x1, y1, ts, { scale: s });
        if (tile2 !== -1) drawTile(ctx, tile2, x2, y2, ts, { scale: s });
        if (a.progress >= 1) { doneAnims.push(i); if (a.onDone) a.onDone(); }
      } else if (a.type === 'match') {
        animatedCells.add(`${a.r},${a.c}`);
        const s = 1 - a.progress;
        const alpha = 1 - a.progress;
        const glow = a.progress;
        if (s > 0 && a.tile !== -1) drawTile(ctx, a.tile, a.c * ts, a.r * ts, ts, { scale: s, alpha, glowPulse: glow });
        if (a.progress >= 1) doneAnims.push(i);
      }
    }

    // Remove done animations
    for (const i of doneAnims.sort((a,b) => b-a)) this.animations.splice(i, 1);

    // Draw static cells
    for (let r = 0; r < this.board.rows; r++) {
      for (let c = 0; c < this.board.cols; c++) {
        if (animatedCells.has(`${r},${c}`)) continue;
        const tile = this.board.get(r, c);
        if (tile === -1) continue;
        const isSelected = selectedCell && selectedCell.r === r && selectedCell.c === c;
        const isHovered = hoveredCell && hoveredCell.r === r && hoveredCell.c === c;
        const glowPulse = isSelected ? (0.5 + 0.5 * Math.sin(time * 0.004)) : 0;
        const scale = isSelected ? 1.08 : isHovered ? 1.03 : 1;
        drawTile(ctx, tile, c * ts, r * ts, ts, { selected: isSelected, scale, glowPulse });
      }
    }

    // Selection ring highlight
    if (selectedCell) {
      const { r, c } = selectedCell;
      ctx.save();
      ctx.strokeStyle = `rgba(255,255,255,${0.6 + 0.4 * Math.sin(time * 0.006)})`;
      ctx.lineWidth = 3;
      ctx.shadowColor = '#a855f7';
      ctx.shadowBlur = 20;
      ctx.strokeRect(c * ts + 4, r * ts + 4, ts - 8, ts - 8);
      ctx.restore();
    }

    ctx.restore();
  }

  _drawBoardBg(ctx, ts) {
    const cols = this.board.cols;
    const rows = this.board.rows;
    // Board background
    ctx.fillStyle = 'rgba(5,0,20,0.7)';
    ctx.beginPath();
    roundRectPath(ctx, 0, 0, cols * ts, rows * ts, 12);
    ctx.fill();

    // Grid lines
    ctx.strokeStyle = 'rgba(120,80,200,0.25)';
    ctx.lineWidth = 1;
    for (let r = 0; r <= rows; r++) {
      ctx.beginPath();
      ctx.moveTo(0, r * ts);
      ctx.lineTo(cols * ts, r * ts);
      ctx.stroke();
    }
    for (let c = 0; c <= cols; c++) {
      ctx.beginPath();
      ctx.moveTo(c * ts, 0);
      ctx.lineTo(c * ts, rows * ts);
      ctx.stroke();
    }

    // Board border glow
    ctx.strokeStyle = 'rgba(168,85,247,0.6)';
    ctx.lineWidth = 2;
    ctx.shadowColor = '#a855f7';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    roundRectPath(ctx, 0, 0, cols * ts, rows * ts, 12);
    ctx.stroke();
    ctx.shadowBlur = 0;
  }
}

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function easeOutBounce(t) {
  if (t < 1/2.75) return 7.5625*t*t;
  if (t < 2/2.75) return 7.5625*(t-=1.5/2.75)*t+0.75;
  if (t < 2.5/2.75) return 7.5625*(t-=2.25/2.75)*t+0.9375;
  return 7.5625*(t-=2.625/2.75)*t+0.984375;
}

function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
