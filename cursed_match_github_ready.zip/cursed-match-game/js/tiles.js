// Tile definitions for Jujutsu Kaisen Match-3
// Each tile is drawn procedurally on canvas for a vibrant anime look

export const TILE_TYPES = [
  { id: 0, name: 'cursed_energy',  emoji: '⚡', label: '咒力',  color1: '#6366f1', color2: '#a855f7', glow: '#a855f7' },
  { id: 1, name: 'talisman',       emoji: '📜', label: '符術',  color1: '#f97316', color2: '#fbbf24', glow: '#fbbf24' },
  { id: 2, name: 'cursed_spirit',  emoji: '👁', label: '呪霊',  color1: '#10b981', color2: '#34d399', glow: '#34d399' },
  { id: 3, name: 'black_flash',    emoji: '✦',  label: '黒閃',  color1: '#0ea5e9', color2: '#38bdf8', glow: '#38bdf8' },
  { id: 4, name: 'sukuna_finger',  emoji: '✋', label: '指',   color1: '#ef4444', color2: '#f87171', glow: '#ef4444' },
  { id: 5, name: 'infinity',       emoji: '∞',  label: '無限',  color1: '#e2e8f0', color2: '#94a3b8', glow: '#ffffff' },
];

export const NUM_TYPES = TILE_TYPES.length;
export const TILE_SIZE = 70; // base size, scaled dynamically

/**
 * Draw a tile onto a canvas context at (x, y) with the given size.
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} tileId
 * @param {number} x
 * @param {number} y
 * @param {number} size
 * @param {object} opts - { selected, matched, scale, alpha, glowPulse }
 */
export function drawTile(ctx, tileId, x, y, size, opts = {}) {
  const tile = TILE_TYPES[tileId];
  if (!tile) return;

  const {
    selected = false,
    scale = 1,
    alpha = 1,
    glowPulse = 0,
  } = opts;

  ctx.save();
  ctx.globalAlpha = alpha;

  const cx = x + size / 2;
  const cy = y + size / 2;
  const s = size * scale;
  const r = s * 0.42; // inner shape radius
  const pad = size * (1 - scale) / 2;
  const tx = x + pad;
  const ty = y + pad;

  // Glow effect
  const glowRadius = s * 0.55 + glowPulse * 15;
  const glowGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, glowRadius);
  glowGrad.addColorStop(0, hexToRgba(tile.glow, 0.35 + glowPulse * 0.3));
  glowGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = glowGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, glowRadius, 0, Math.PI * 2);
  ctx.fill();

  // Tile background rounded rect
  const bgRadius = s * 0.18;
  ctx.beginPath();
  roundRect(ctx, tx + 2, ty + 2, s - 4, s - 4, bgRadius);
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fill();

  // Background gradient
  const bgGrad = ctx.createLinearGradient(tx, ty, tx + s, ty + s);
  bgGrad.addColorStop(0, hexToRgba(tile.color1, 0.9));
  bgGrad.addColorStop(1, hexToRgba(tile.color2, 0.85));
  ctx.beginPath();
  roundRect(ctx, tx + 2, ty + 2, s - 4, s - 4, bgRadius);
  ctx.fillStyle = bgGrad;
  ctx.fill();

  // Border
  ctx.beginPath();
  roundRect(ctx, tx + 2, ty + 2, s - 4, s - 4, bgRadius);
  if (selected) {
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 12;
  } else {
    ctx.strokeStyle = hexToRgba(tile.glow, 0.7);
    ctx.lineWidth = 1.5;
  }
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Inner shine
  const shineGrad = ctx.createLinearGradient(tx, ty, tx, ty + s * 0.5);
  shineGrad.addColorStop(0, 'rgba(255,255,255,0.3)');
  shineGrad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.beginPath();
  roundRect(ctx, tx + 2, ty + 2, s - 4, s * 0.45, bgRadius);
  ctx.fillStyle = shineGrad;
  ctx.fill();

  // Draw the tile symbol
  drawTileSymbol(ctx, tile, cx, cy, s);

  // Label text (kanji)
  ctx.fillStyle = 'rgba(255,255,255,0.75)';
  ctx.font = `bold ${s * 0.16}px Rajdhani, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  ctx.fillText(tile.label, cx, ty + s - 3);

  ctx.restore();
}

function drawTileSymbol(ctx, tile, cx, cy, s) {
  ctx.save();
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  switch (tile.id) {
    case 0: // Cursed Energy — lightning bolt
      drawLightning(ctx, cx, cy, s * 0.45, tile.color1, tile.glow);
      break;
    case 1: // Talisman — scroll/paper
      drawTalisman(ctx, cx, cy, s * 0.42, tile.color2);
      break;
    case 2: // Cursed Spirit — eye
      drawEye(ctx, cx, cy, s * 0.38, tile.color2, tile.glow);
      break;
    case 3: // Black Flash — cross burst
      drawBlackFlash(ctx, cx, cy, s * 0.42, tile.color2);
      break;
    case 4: // Sukuna Finger — tattoo hand
      drawSukunaFinger(ctx, cx, cy, s * 0.4, tile.color1, tile.glow);
      break;
    case 5: // Infinity — infinity symbol
      drawInfinity(ctx, cx, cy, s * 0.38, tile.color2, tile.glow);
      break;
    default:
      ctx.font = `${s * 0.5}px serif`;
      ctx.fillStyle = 'white';
      ctx.fillText(tile.emoji, cx, cy);
  }
  ctx.restore();
}

function drawLightning(ctx, cx, cy, r, color1, color2) {
  ctx.save();
  // Glow
  ctx.shadowColor = color2;
  ctx.shadowBlur = 10;
  // Lightning bolt shape
  const pts = [
    [cx + r*0.2, cy - r],
    [cx - r*0.15, cy - r*0.05],
    [cx + r*0.3, cy - r*0.05],
    [cx - r*0.2, cy + r],
    [cx + r*0.1, cy + r*0.1],
    [cx - r*0.25, cy + r*0.1],
  ];
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.closePath();
  const g = ctx.createLinearGradient(cx, cy - r, cx, cy + r);
  g.addColorStop(0, '#ffffff');
  g.addColorStop(0.5, color2);
  g.addColorStop(1, color1);
  ctx.fillStyle = g;
  ctx.fill();
  ctx.restore();
}

function drawTalisman(ctx, cx, cy, r, color) {
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = 8;
  // Paper scroll
  ctx.fillStyle = 'rgba(255,245,200,0.9)';
  ctx.beginPath();
  roundRect(ctx, cx - r*0.6, cy - r*0.85, r*1.2, r*1.7, 4);
  ctx.fill();
  // Red kanji lines
  ctx.strokeStyle = '#dc2626';
  ctx.lineWidth = 2;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(cx - r*0.4, cy + i * r*0.3);
    ctx.lineTo(cx + r*0.4, cy + i * r*0.3);
    ctx.stroke();
  }
  // Center kanji mark
  ctx.font = `bold ${r*0.7}px serif`;
  ctx.fillStyle = '#dc2626';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('符', cx, cy);
  ctx.restore();
}

function drawEye(ctx, cx, cy, r, color, glow) {
  ctx.save();
  ctx.shadowColor = glow;
  ctx.shadowBlur = 12;
  // Eye white (black sclera for cursed spirit)
  ctx.beginPath();
  ctx.ellipse(cx, cy, r, r*0.55, 0, 0, Math.PI*2);
  ctx.fillStyle = '#0f1a0f';
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.stroke();
  // Iris
  ctx.beginPath();
  ctx.arc(cx, cy, r*0.38, 0, Math.PI*2);
  const irg = ctx.createRadialGradient(cx, cy, 0, cx, cy, r*0.38);
  irg.addColorStop(0, '#fde68a');
  irg.addColorStop(0.6, color);
  irg.addColorStop(1, '#064e3b');
  ctx.fillStyle = irg;
  ctx.fill();
  // Pupil
  ctx.beginPath();
  ctx.ellipse(cx, cy, r*0.1, r*0.2, 0, 0, Math.PI*2);
  ctx.fillStyle = '#000';
  ctx.fill();
  // Glint
  ctx.beginPath();
  ctx.arc(cx + r*0.12, cy - r*0.12, r*0.07, 0, Math.PI*2);
  ctx.fillStyle = 'rgba(255,255,255,0.8)';
  ctx.fill();
  ctx.restore();
}

function drawBlackFlash(ctx, cx, cy, r, color) {
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = 15;
  const arms = 8;
  for (let i = 0; i < arms; i++) {
    const angle = (i / arms) * Math.PI * 2;
    const innerR = r * 0.15;
    const outerR = r * (i % 2 === 0 ? 1 : 0.55);
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * innerR, cy + Math.sin(angle) * innerR);
    ctx.lineTo(cx + Math.cos(angle) * outerR, cy + Math.sin(angle) * outerR);
    ctx.strokeStyle = i % 2 === 0 ? color : 'rgba(255,255,255,0.7)';
    ctx.lineWidth = i % 2 === 0 ? 3 : 2;
    ctx.stroke();
  }
  // Center circle
  ctx.beginPath();
  ctx.arc(cx, cy, r*0.2, 0, Math.PI*2);
  const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, r*0.2);
  cg.addColorStop(0, '#ffffff');
  cg.addColorStop(1, color);
  ctx.fillStyle = cg;
  ctx.fill();
  ctx.restore();
}

function drawSukunaFinger(ctx, cx, cy, r, color, glow) {
  ctx.save();
  ctx.shadowColor = glow;
  ctx.shadowBlur = 10;
  // Finger shape
  ctx.beginPath();
  ctx.moveTo(cx - r*0.25, cy + r);
  ctx.quadraticCurveTo(cx - r*0.3, cy - r*0.5, cx, cy - r);
  ctx.quadraticCurveTo(cx + r*0.3, cy - r*0.5, cx + r*0.25, cy + r);
  ctx.closePath();
  const fg = ctx.createLinearGradient(cx - r*0.3, cy - r, cx + r*0.3, cy + r);
  fg.addColorStop(0, '#fde8d8');
  fg.addColorStop(1, '#d97706');
  ctx.fillStyle = fg;
  ctx.fill();
  // Tattoo lines
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 3; i++) {
    const yy = cy - r*0.3 + i * r*0.35;
    ctx.beginPath();
    ctx.moveTo(cx - r*0.2, yy);
    ctx.lineTo(cx + r*0.2, yy);
    ctx.stroke();
  }
  // Nail
  ctx.beginPath();
  ctx.ellipse(cx, cy - r*0.78, r*0.15, r*0.1, 0, 0, Math.PI*2);
  ctx.fillStyle = 'rgba(180,140,120,0.8)';
  ctx.fill();
  ctx.restore();
}

function drawInfinity(ctx, cx, cy, r, color, glow) {
  ctx.save();
  ctx.shadowColor = glow;
  ctx.shadowBlur = 15;
  ctx.strokeStyle = color;
  ctx.lineWidth = r * 0.18;
  ctx.lineCap = 'round';
  // Lemniscate approximation using bezier curves
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.bezierCurveTo(cx - r*0.3, cy - r*0.7, cx - r*1.1, cy - r*0.7, cx - r*0.85, cy);
  ctx.bezierCurveTo(cx - r*1.1, cy + r*0.7, cx - r*0.3, cy + r*0.7, cx, cy);
  ctx.bezierCurveTo(cx + r*0.3, cy - r*0.7, cx + r*1.1, cy - r*0.7, cx + r*0.85, cy);
  ctx.bezierCurveTo(cx + r*1.1, cy + r*0.7, cx + r*0.3, cy + r*0.7, cx, cy);
  ctx.stroke();
  // Center dot
  ctx.beginPath();
  ctx.arc(cx, cy, r*0.1, 0, Math.PI*2);
  ctx.fillStyle = 'rgba(255,255,255,0.9)';
  ctx.fill();
  ctx.restore();
}

// Helper: rounded rect path
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1,3),16);
  const g = parseInt(hex.slice(3,5),16);
  const b = parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${alpha})`;
}
