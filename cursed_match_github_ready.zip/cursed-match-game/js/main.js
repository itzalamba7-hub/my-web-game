// Entry point
import { Game } from './game.js';

document.addEventListener('DOMContentLoaded', () => {
  // Ambient background particles (floating cursed energy)
  const bgParticleCanvas = document.createElement('canvas');
  bgParticleCanvas.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2;';
  document.getElementById('particle-layer').appendChild(bgParticleCanvas);
  const bgCtx = bgParticleCanvas.getContext('2d');
  const bgParticles = [];

  function resizeBgCanvas() {
    bgParticleCanvas.width = window.innerWidth;
    bgParticleCanvas.height = window.innerHeight;
  }
  resizeBgCanvas();
  window.addEventListener('resize', resizeBgCanvas);

  // Spawn ambient floating energy orbs
  for (let i = 0; i < 25; i++) {
    bgParticles.push({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      vx: (Math.random() - 0.5) * 0.4,
      vy: -0.2 - Math.random() * 0.6,
      size: 1.5 + Math.random() * 3,
      alpha: 0.2 + Math.random() * 0.5,
      color: ['#a855f7','#6366f1','#38bdf8','#e879f9'][Math.floor(Math.random()*4)],
      pulse: Math.random() * Math.PI * 2,
    });
  }

  function animateBg() {
    bgCtx.clearRect(0, 0, bgParticleCanvas.width, bgParticleCanvas.height);
    const t = performance.now() * 0.001;
    for (const p of bgParticles) {
      p.x += p.vx;
      p.y += p.vy;
      p.pulse += 0.03;
      if (p.y < -10) { p.y = bgParticleCanvas.height + 10; p.x = Math.random() * bgParticleCanvas.width; }
      if (p.x < -10) p.x = bgParticleCanvas.width + 10;
      if (p.x > bgParticleCanvas.width + 10) p.x = -10;
      const a = p.alpha * (0.7 + 0.3 * Math.sin(p.pulse));
      bgCtx.save();
      bgCtx.globalAlpha = a;
      bgCtx.beginPath();
      bgCtx.arc(p.x, p.y, p.size * (1 + 0.2 * Math.sin(p.pulse)), 0, Math.PI * 2);
      bgCtx.fillStyle = p.color;
      bgCtx.shadowColor = p.color;
      bgCtx.shadowBlur = p.size * 4;
      bgCtx.fill();
      bgCtx.restore();
    }
    requestAnimationFrame(animateBg);
  }
  animateBg();

  // Init game
  const game = new Game();

  // Show start screen
  document.getElementById('screen-start').classList.add('active');

  // Resume AudioContext on first touch (mobile requirement)
  const resumeAudio = () => {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (AudioContext) {
      const tmpCtx = new AudioContext();
      tmpCtx.resume().then(() => tmpCtx.close());
    }
    document.removeEventListener('pointerdown', resumeAudio);
  };
  document.addEventListener('pointerdown', resumeAudio);
});
