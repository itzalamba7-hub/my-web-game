# Checkpoint — Cursed Match (JJK Match-3)

## Completed
- `index.html` — full layout: start screen, HUD (score/level/moves), game canvas, level-complete + game-over modals
- `css/style.css` — full JJK dark anime aesthetic, responsive, mobile-ready, fonts, animations
- `js/tiles.js` — 6 tile types (cursed energy ⚡, talisman 📜, cursed eye 👁, black flash ✦, sukuna finger ✋, infinity ∞), all drawn procedurally on canvas with glows, kanji labels
- `js/board.js` — full Board class: grid init (no pre-existing matches), match finding (H+V), clearing, gravity, refill, shuffle when no moves
- `js/renderer.js` — canvas Renderer: dynamic sizing, cell-to-screen mapping, swap/fall/match animations, screen shake, selection highlight
- `js/particles.js` — ParticleSystem: match sparks, explosions, floating score text, kanji burst effects
- `js/audio.js` — Web Audio API synthesized SFX: match ping, big match, combo chords, invalid swap, swap click, level up fanfare, game over, looping ambient BGM
- `js/levels.js` — 20 levels with JJK chapter titles, scaling difficulty (score targets, move counts, board sizes 6×6→8×8), unique rewards
- `js/game.js` — Game controller: state machine, pointer/drag input, swap validation, async match→gravity→refill chain, combo tracking, level complete/game over logic
- `js/main.js` — Entry point: ambient floating particle background, Game init, AudioContext resume on first touch
- `DESIGN.md` — design doc

## What Remains (Optional Enhancements)
- Special tile power-ups (row-clear, bomb on 4-5 matches) — board.js getMatchType() is scaffolded
- High score persistence (localStorage)
- More character art / imported images for tile faces
- Sound volume controls
- Level select screen

## Recommended Next Step
The game is fully playable. To enhance: implement special tiles (4-match = row-clear, 5-match = board bomb) by handling `matchType` in game.js `_processMatches()` and creating special tile state in Board.
