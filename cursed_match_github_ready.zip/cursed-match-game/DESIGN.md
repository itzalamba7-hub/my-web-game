## Cursed Match — Jujutsu Kaisen Match-3
Concept: Candy Crush-style match-3 puzzle game with JJK anime theme.
Core Mechanic: Swap adjacent tiles (cursed energy, talismans, eyes, etc.) to match 3+ for score. Combo chains, 20 levels, particles.
Art Style: Dark purple/black anime aesthetic, canvas-drawn procedural tiles with glows, kanji labels.
