# Cursed Match Game

Upload this folder to GitHub and open index.html to run the game.